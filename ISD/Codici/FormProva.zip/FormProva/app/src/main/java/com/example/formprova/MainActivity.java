package com.example.formprova;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends ActionBarActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
	
	

	public void onRadioButtonClicked(View view) {
	    CharSequence cs = ((RadioButton)(view)).getText();
	    EditText te = (EditText) findViewById(R.id.editText1);
	    te.setText(cs);
	}
	
	public void onInvia(View view){
		EditText te = (EditText) findViewById(R.id.editText1);
		CharSequence cs = te.getText();
	    TextView tv = (TextView) findViewById(R.id.textView1);
	    tv.setText(cs);
	}
	
	
}
