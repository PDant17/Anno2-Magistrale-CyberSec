package it.unisa.di.aa.sudoku;

public class Sudoku {
	static int[][] n4 = { {0,0,3,0}, {1,0,0,0}, {0,2,0,0}, {0,0,0,4} };
		
	static int[][] n9 = { 
		{0,0,0,9,0,0,0,4,0},
		{0,1,0,0,0,0,0,0,0},
		{0,0,2,0,0,0,0,0,0},
		{0,0,0,3,0,0,0,0,0},
		{0,8,0,0,0,6,0,0,0},
		{0,0,0,0,0,0,0,0,0},
		{0,4,0,0,0,0,8,0,0},
		{0,0,0,0,0,0,0,9,0},
		{0,5,0,0,0,0,0,0,0} };

	static int[][] n16 = { 
		{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0} };

	static int size = 16;
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Solution sol = new Solution(n16,size,0);
		Solution sol2 = recursion(sol);
		
		if (sol2 != null) {
			sol2.print();
			System.out.println("Solution is: "+sol2.isLegal());
		}
		else {
			System.out.println("No solution");
		}
	}
	
	
	private static Solution recursion(Solution s) {
		int rl = s.getRecursionLevel();
		System.out.println("Recursive level="+rl);
		if (!s.isLegal()) {
			//System.out.println("s is not legal");
			return null;
		}
		if (s.isComplete()) return s;
		//recursion
		//find an empty cell
		Coordinates point = s.getEmptyCell();
		if (point == null) {
			System.out.println("point is null. Cannot be!");
		}
		//fill all possible values
		for (int v=1; v<size+1; v++) {
			//System.out.println("iteration v="+v);
			//Il meotodo clone di Java non funziona!!!
			Solution news= new Solution(s.getNumeri(),size,rl+1);
			news.setCell(point.getR(),point.getC(),v);
			Solution r = recursion(news);
			if (r != null) return r;
		}
		System.out.println("Tried all possibilities. Returning null");
		return null;
	}
}

