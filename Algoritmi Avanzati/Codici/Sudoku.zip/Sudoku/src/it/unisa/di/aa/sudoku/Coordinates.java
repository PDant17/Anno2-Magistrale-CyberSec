package it.unisa.di.aa.sudoku;

public class Coordinates {
	int r;
	int c;
	
	public Coordinates(int r, int c) {
		this.r = r;
		this.c = c;
	}
	
	public int getR() {
		return r;
	}

	public int getC() {
		return c;
	}

}
