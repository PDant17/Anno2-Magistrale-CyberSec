package it.unisa.di.aa.sudokuforzabruta;

class Solution implements Cloneable  {
	int[][] numeri;
	int size;
	int sqrsize;
	int recursion_level;
	
	public Solution(int[][] numeri, int size, int rl) {
		this.size = size;
		this.recursion_level = rl;
		sqrsize = (int) Math.sqrt(size);
		this.numeri = new int[size][size];
		//this.numeri = numeri ---> Copierebbe solo l'indirizzo dell'array!!!
		for (int i=0; i<size; i++) {
		 	for (int j=0; j<size; j++) {
				this.numeri[i][j]=numeri[i][j];
			}
		}
	}
	
	public int[][] getNumeri() {
		return numeri;
	}
	
	public int getRecursionLevel() {
		return recursion_level;
	}
	
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
	public int getValue(int r, int c) {
		return numeri[r][c];
	}
	
	public void setCell(int r, int c, int value) {
		System.out.println(String.format("Setting cell [%d][%d]=%d in solution "+this,r,c,value));
		numeri[r][c] = value;
	}

	private boolean existsDuplicate(int[] n) {
		//System.out.print("Controllo:");
		//for (int i=0; i<n.length; i++) System.out.print(" "+n[i]);
		//System.out.println("");
		boolean flag = false;
		for (int i=0; i<n.length; i++) {
			if (n[i]==0) continue;
			for (int j=0; j<n.length; j++) {
				if (n[j]==0) continue;
				if ((n[i] == n[j]) && (i != j)) flag=true;
			}				
		}
		return flag;
	}
	
	public boolean isLegal() {
		boolean flag = true;
		for (int i=0; i<size; i++) {
			//Check column i
			if (existsDuplicate(numeri[i])) {
				//System.out.println("Riga "+i);
				return false;
			}
			//Check row i
			int[] row = new int[size];
			for (int j=0; j<size; j++) {
				row[j]=numeri[j][i];
			}
			if (existsDuplicate(row)) {
				//System.out.println("Colonna "+i);
				return false;
			}
		}
		//Check subsquares
		for (int s1=0; s1<sqrsize; s1++) {
			for (int s2=0; s2<sqrsize; s2++) {
				int[] subsquare = new int[size];	
				int k=0;
				for (int i=0; i<sqrsize; i++) {
					for (int j=0; j<sqrsize; j++) {
						subsquare[k++]=numeri[s1*sqrsize+i][s2*sqrsize+j];
					}	
				}
				if (existsDuplicate(subsquare)) {
					//System.out.println("Sottomatrice "+s1+" "+s2);
					return false;
				}
			}
		}
		return true;
	}
	
	public int howMany() {
		int c=0;
		for (int i=0; i<size; i++) {
			for (int j=0; j<size; j++) {
				if (numeri[i][j] != 0) c++;
			}
		}
		return c;
	}

	public boolean isComplete() {
		return (this.howMany() == size*size);
	}
	
	public Coordinates getEmptyCell() {
		for (int i=0; i<size; i++) {
			for (int j=0; j<size; j++) {
				if (numeri[i][j] == 0) {
					Coordinates point = new Coordinates(i, j);
					return point;
				}
			}
		}
		return null;
	}

	public void print() {
		int c=0;
		System.out.println("solution: "+this);
		for (int i=0; i<size; i++) {
			for (int j=0; j<size; j++) {
				System.out.print(" "+numeri[i][j]);
			}
			System.out.println("");
		}
		System.out.println("-----------");
	}
}
