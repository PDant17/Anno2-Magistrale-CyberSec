package it.unisa.di.aa.sudokuforzabruta;

public class Sudoku {
	static int[][] n4 = { 
		{1,3,4,2}, 
		{2,4,3,1}, 
		{3,2,1,4}, 
		{0,0,2,3} };
		
	static int[][] n9 = { 
		{0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0,0} };
	

	static int size = 4;
	
	static int counter = 1;
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Solution sol = new Solution(n4,size,0);
		Solution sol2 = recursion(sol);
		
		if (sol2 != null) {
			sol2.print();
			System.out.println("Solution is: "+sol2.isLegal());
		}
		else {
			System.out.println("No solution");
		}
	}
	
	
	private static Solution recursion(Solution s) {
		int rl = s.getRecursionLevel();
		System.out.println("Recursive level="+rl);
		Coordinates point = s.getEmptyCell();
		if (point == null) {
			//Solution is complete
			if (s.isLegal() && s.isComplete()) {
				return s;
			}
			else {
				return null;
			}
		}
		//fill all possible values
		for (int v=1; v<size+1; v++) {
			//System.out.println("iteration v="+v);
			//Il meotodo clone di Java non funziona!!!
			Solution news= new Solution(s.getNumeri(),size,rl+1);
			news.setCell(point.getR(),point.getC(),v);
			Solution r = recursion(news);
			if (r != null) return r;
		}
		System.out.println("Tried all possibilities. Returning null. counter="+counter++);
		return null;
	}
}

